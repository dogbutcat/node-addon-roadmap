#pragma once
#include <node.h>

using namespace v8;


void Init(Local<Object> exports);