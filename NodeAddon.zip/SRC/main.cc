#include "main.h"


void Init(Local<Object> exports)
{
}

NODE_MODULE($safeprojectname$, Init)
